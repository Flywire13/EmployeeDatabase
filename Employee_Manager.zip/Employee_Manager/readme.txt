Employee_Manager Program
Team 4 - Fall 2022

Steps to Install:
    1. Download the ZIP folder containing the application: Employee_Manager.exe
    2. Start the install by double clicking the executable
    3. Follow the prompts to complete the install
    4. Run the program after finishing the install by double clicking the executable
    Note: See Sprint 4 Submission document for full instructions and screenshots

Example Login Info:
    Admin - Karina Gay
    Username: 688997
    Password: qwerty!123

    Non-Admin - Yoko M. Pitts
    Username: 939825
    Password: qwerty!127




